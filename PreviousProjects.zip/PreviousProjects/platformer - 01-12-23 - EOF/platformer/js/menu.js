class menu extends Phaser.Scene 
{
   constructor()
   { //Crear escena
        super({key: "menu"});
   }

   init()
   {//Pintar todo lo que se va a ver en pantalla mientras se cargan los assets
        this.bg = this.add.tileSprite(0,0,gamePrefs.gameWidth,
        gamePrefs.gameHeight,'bg_green').setOrigin(0);
        this.bar=this.add.rectangle(150,200,200,20).setOrigin(0,.5);
        this.bar.setStrokeStyle(2,0xFFFFFF);
        
        this.fill = this.add.rectangle(154,200,0,12,0xFFFFFF).setOrigin(0,.5);
        
        this.perText = this.add.bitmapText(
            164,
            180,
            'titleFont',
            "Loading... 0%",
            12)
            .setCenterAlign()
            .setOrigin(0,.5);

        this.perText.valor = 0;
   }

   preload()
   { //Cargamos assets
        this.load.setPath('assets/sprites');
        this.load.image('puerta','spr_door_open_0.png');
        this.load.image('gemUI','spr_gui_gem_0.png');

        
        this.load.spritesheet('healthUI','health.png',
        {frameWidth:128,frameHeight:28});

        this.load.setPath('assets/tilesets');
        this.load.image('walls_tileset','tileset_walls.png');
        this.load.image('moss_tileset','tileset_moss.png');
        
        this.load.setPath('assets/sounds');
        
        this.load.setPath('assets/maps');
        this.load.tilemapTiledJSON('level1','level1.json');

        this.load.setPath('assets/fonts/');
        this.load.bitmapFont('UIFont','gameFont.png','gameFont.xml'); 
        
        this.loadAnimations();

        // ARRIBA ESTÁ TODO LO QUE QUIERO PRECARGAR
        this.load.on('progress',function(value)
        {
            var num = Phaser.Math.RoundTo(value*100,0);
            var fillWdith = Phaser.Math.RoundTo(num/100*192);
            this.fill.setSize(fillWdith,this.fill.height);
            this.perText.text = "Loading... "+ num +" %";
        },this);

        this.load.on('complete',function()
        {
            console.log('completed');
            this.finalizaCarga();
        },this);
   }

   create(){}

   finalizaCarga()
   {
    this.hero = this.add.sprite(100,120,'hero').setScale(2);
    this.hero.anims.play('run',true);

    this.slime = this.add.sprite(400,120,'slime').setScale(2);
    this.slime.anims.play('slime',true);
    this.slime.flipX = true;
    
    this.runHero();

    this.cursores = this.input.keyboard.createCursorKeys();            

    this.titleText = this.add.bitmapText(
        gamePrefs.gameWidth/2/2,
        40,
        'titleFont',
        "ENTI-UB's adventure\nin a far old planet",
        24)
        .setCenterAlign()
        .setOrigin(.5);

    this.time.addEvent(
        {
            //delay: 5000,
            callback: this.ocultaLoader,
            callbackScope: this,
            repeat: 0
        }
    );

   }

   runHero()
   {
    this.hero.anims.play('run',true);  
    this.time.addEvent(
        {
            delay: 5000,
            callback: this.shootHero,
            callbackScope: this,
            repeat: 0
        }
    );
   }

   shootHero()
   {
    this.hero.setFrame(1);
    this.hero.stop();
    this.time.addEvent(
        {
            delay: 2000,
            callback: this.runHero,
            callbackScope: this,
            repeat: 0
        }
    );  
   }

   ocultaLoader()
   {
       this.bar.destroy();
       this.fill.destroy();
       this.perText.destroy();
       this.buttonText = this.add.bitmapText(
        gamePrefs.gameWidth/2/2,
        240,
        'titleFont',
        "Press SPACE\nto start!",
        12)
        .setCenterAlign()
        .setOrigin(.5)
        .setInteractive({useHandCursor:true})
        .on
        (
            'pointerdown',
            this.iniciaJuego,
            this
        );

        this.add.tween
         ({
            targets:this.buttonText,
            duration:1000,
            alpha:0,
            //x:this.buttonText.x+5,
            yoyo:true,
            repeat:-1
        });
   }

   loadAnimations()
   {
    this.anims.create(
        {
            key: 'run',
            frames:this.anims.generateFrameNumbers('hero', {start:2, end: 5}),
            frameRate: 10,
            repeat: -1
        }); 
        
        this.anims.create
        ({
            key:'jumper',
            frames:this.anims.generateFrameNumbers('jumper',{start:0,end:3}),
            frameRate:10,
            repeat:-1
        });

        this.anims.create
        ({
            key:'slime',
            frames:this.anims.generateFrameNumbers('slime',{start:0,end:3}),
            frameRate:10,
            repeat:-1
        });

        this.anims.create
        ({
            key:'gem',
            frames:this.anims.generateFrameNumbers('gem',{start:0,end:4}),
            frameRate:10,
            repeat:-1
        });
   }

   iniciaJuego()
   {
        this.scene.start('level1');
   }

   update()
   {//actualizar assets
        if(this.cursores.space.isDown)
        {
            this.iniciaJuego()
        } 
    
        if (this.cursores.right.isDown)
        {
            this.fill.setSize(this.fill.width+1,this.fill.height);
            this.perText.text = "Loading... "+this.perText.valor++ +" %";
        }
    }

}