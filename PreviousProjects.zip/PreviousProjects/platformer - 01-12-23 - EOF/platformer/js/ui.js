class ui extends Phaser.GameObjects.Sprite 
{
    constructor(_scene)
    { //instanciar el objeto
        /*
        super(_scene,5,5,'healthUI').setOrigin(0).setScrollFactor(0);
        _scene.add.existing(this);
        super(_scene,5,5,'healthUI').setOrigin(0).setScrollFactor(0);
        _scene.add.existing(this);
        */
    }
}
/*
this.gemUIText = this.add.bitmapText(
    gamePrefs.gameWidth/2-5,10,'UIFont','x20',20)
.setOrigin(1,0);

this.gemUIText.setScrollFactor(0);

this.healthUI = this.add.sprite(5,5,'healthUI')
.setOrigin(0)
.setScrollFactor(0);
*/