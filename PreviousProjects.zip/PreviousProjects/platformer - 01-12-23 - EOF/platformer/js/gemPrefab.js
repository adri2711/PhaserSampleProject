class gemPrefab extends Phaser.GameObjects.Sprite 
{
    constructor(_scene,_gem)
    { //instanciar el objeto
        super(_scene,_gem.posX,_gem.posY,_gem.spriteTag);
        _scene.add.existing(this);
        _scene.physics.world.enable(this);
        this.gem = this;
        this.gem.body.setAllowGravity(false);
        this.anims.play(_gem.spriteTag,true);
        this.scene = _scene;
        this.value = _gem.points;
        if(this.value>1)
        {
            this.setTint(0xFF0000);
        }
        this.setColliders();
    }

    setColliders()
    {
        this.scene.physics.add.overlap
        (
            this.scene.hero,
            this.gem,
            this.getGem,
            null,
            this
        );
    }

    getGem()
    {
        this.scene.updateScore(this.value);
        this.gem.destroy();       
    }
}  