class preloader extends Phaser.Scene 
{
    constructor()
    { //Crear escena
       super({key: "preloader"});
    }

    preload()
    {  //cargamos los assets mínimos necesarios para el loader
        this.load.setPath('assets/sprites/');
        this.load.image('bg_green','bg_green_tile.png');
        this.load.spritesheet('hero','hero.png',
        {frameWidth:32,frameHeight:32});
        this.load.spritesheet('slime','slime.png',
        {frameWidth:32,frameHeight:32});
        this.load.spritesheet('jumper','jumper.png',
        {frameWidth:32,frameHeight:32});
        this.load.spritesheet('gem','gem.png',
        {frameWidth:32,frameHeight:32});

        this.load.setPath('assets/fonts/');
        this.load.bitmapFont('titleFont','titleFont.png','titleFont.xml'); 

        this.load.on('complete',function()
        {
            this.scene.start('menu');
        },this);
    }

    create(){}

    update(){}
}	 