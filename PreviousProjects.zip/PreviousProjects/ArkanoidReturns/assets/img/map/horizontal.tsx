<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="horizontal" tilewidth="1" tileheight="1" tilecount="7424" columns="232">
 <image source="../border/horizontal.png" width="232" height="32"/>
</tileset>
